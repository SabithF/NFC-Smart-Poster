

const styles= {
    paddingX: "sm:px-16 px-6",
    paddingY: "sm:py-16 py-6",
    padding: "sm:px-16 px-6 sm:py-16 py-10",


    dashBoardBackground: "min-h-screen border-gray-200 dark:bg-gradient-to-b from-gray-900 via-gray-900 to-gray-900"
}

export {styles}